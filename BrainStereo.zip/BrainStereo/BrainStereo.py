import vtk,slicer
from slicer.ScriptedLoadableModule import *
from slicer.util import VTKObservationMixin
import math,functools
import numpy as np
from Resources.stereoLogic import stereoLogic
import qt

class BrainStereo(ScriptedLoadableModule):

  def __init__(self, parent):
    ScriptedLoadableModule.__init__(self, parent)
    self.parent.title = "BrainStereo"  # TODO: make this more human readable by adding spaces
    self.parent.categories = ["Neurosurgery"] 
    self.parent.dependencies = []  # TODO: add here list of module names that this module requires
    self.parent.contributors = ["xmszj"]  # TODO: replace with "Firstname Lastname (Organization)"
    # TODO: update with short description of the module and a link to online module documentation
    self.parent.helpText = """https://github.com/xmszj/BrainStereo"""
    # TODO: replace with organization, grant and thanks
    self.parent.acknowledgementText = """Thanks for 3DSlicer Forum """

class BrainStereoWidget(ScriptedLoadableModuleWidget, VTKObservationMixin):

  def __init__(self, parent=None):
    ScriptedLoadableModuleWidget.__init__(self, parent)
    VTKObservationMixin.__init__(self)  
    self.logic = None

  def setup(self):
    ScriptedLoadableModuleWidget.setup(self)

    uiWidget = slicer.util.loadUI(self.resourcePath('UI/BrainStereo.ui'))
    self.layout.addWidget(uiWidget)
    self.ui = slicer.util.childWidgetVariables(uiWidget)
    uiWidget.setMRMLScene(slicer.mrmlScene)

    self.ui.btn_choose_point.connect('clicked(bool)', self.on_choose_four_point)
    # self.ui.btn_register.connect('clicked(bool)', self.on_register_point)
    self.ui.btn_choose_target_point.connect('clicked(bool)', self.on_add_target_point)
    self.ui.btn_choose_entry_point.connect('clicked(bool)', self.on_add_entry_point)
    self.ui.ctDataSelector.setMRMLScene(slicer.mrmlScene)
    self.ui.btn_clear.connect('clicked(bool)', self.reset)
    
    #transform
    self.ui.pRotateSlicer.valueChanged.connect(self.pRotate)
    self.ui.axRotateSlicer.valueChanged.connect(self.axyzRotate)
    self.ui.axTransSlicer.valueChanged.connect(self.axyzRotate)
    self.ui.ayTransSlicer.valueChanged.connect(self.axyzRotate)
    self.ui.azTransSlicer.valueChanged.connect(self.axyzRotate)

    self.ui.visualizePlanBtn.connect('clicked(bool)', self.loadFrame)
    self.ui.visualizeFrameBtn.connect('clicked(bool)', self.visualFrame)
    self.ui.lockPlanBtn.connect('clicked(bool)', self.lockPlan)
    #self.ui.realTImeBtn.connect('clicked(bool)', self.realTimeTrac)

    self.ui.showBtn.connect('clicked(bool)', self.volumeRender)

    
    self.ui.newPlanBtn.connect('clicked(bool)', self.newPlan)

    self.ui.btn_autoReg.connect('clicked(bool)', self.autoFourpoints)

    self.ui.testBtn.connect('clicked(bool)', self.loadTestCt)

    

    self.defineiVar()

    # self.leksellLib = ctypes.CDLL(slicer.util.loadUI(self.resourcePath('pythonDll.dll')))
    # lib.calculate_xyz lib.calculate_arc  lib.calculate_ring


    #shNode = slicer.mrmlScene.GetSubjectHierarchyNode()
    #sceneItemID = shNode.GetSceneItemID()
    #folderItemId = shNode.CreateFolderItem(sceneItemID , "BrainStereo")

    self.sc=stereoLogic()
    self.sc.initTube()

    self.track=track()

    #self.creatPlanTable()


  def defineiVar(self):
    
    self.sPoints=None  #name=s
    self.fourPoints=None #name=pointset
    self.outputTransformNode=None #name=pTrans
    self.target=None #name=targetPoint
    self.entry=None #name=entryPoint

    self.tubeModel=None #name=tubeModel

    self.frameModel=None
    self.arcModel=None
    self.axialModel=None
    self.pathModel=None
    self.pathTranNode=None
    self.arcTranNode=None

    self.realTimeVis = False
    
####################################################################################### for Rigist Frame    
  def creatPlanTable(self):
        table=self.ui.planTable
        # 设置列宽
        table.horizontalHeader().setSectionResizeMode(0, 1)
        table.horizontalHeader().setSectionResizeMode(1, 1)
        table.horizontalHeader().setSectionResizeMode(2, 1)
        table.horizontalHeader().setSectionResizeMode(3, 1)
        table.horizontalHeader().setSectionResizeMode(4, 2)
        table.horizontalHeader().setSectionResizeMode(5, 2)

  def showStandPoints(self,points): # show standard points

    self.sPoints = slicer.mrmlScene.GetFirstNodeByName("S")
    if (self.sPoints is None):
      self.sPoints = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLMarkupsFiducialNode", "S")
    self.sPoints.RemoveAllControlPoints()

    self.sPoints.SetLocked(1)
     
    display_node = self.sPoints.GetDisplayNode()
    display_node.SetGlyphType(5)
    display_node.SetTextScale(3)
    
    for i in points:
      self.sPoints.AddFiducial(i[0],i[1],i[2])

    #rename 4 points
    name=["A  ","B  ","C  ","D  "]

    for i in range(4):
      self.sPoints.SetNthControlPointLabel(i, name[i])

  def on_choose_four_point(self):#select 4 points
    self.max2D()
    self.fourPoints= slicer.mrmlScene.GetFirstNodeByName("pointset")
    if(self.fourPoints is None):
        #slicer.app.layoutManager().threeDWidget(0).threeDView().lookFromAxis(3)
        self.fourPoints= slicer.mrmlScene.AddNewNodeByClass("vtkMRMLMarkupsFiducialNode", "pointset")
        self.fourPoints.RemoveAllControlPoints()

    self.fourPoints.GetDisplayNode().SetGlyphType(2)
    
    self.fourPoints.AddObserver(slicer.vtkMRMLMarkupsNode.PointAddedEvent, functools.partial(self.on_point_modified, actor="f"))

    interactionNode = slicer.app.applicationLogic().GetInteractionNode()
    selectionNode = slicer.app.applicationLogic().GetSelectionNode()
    selectionNode.SetActivePlaceNodeID(self.fourPoints.GetID())
    placeModePersistence = 1
    interactionNode.SetPlaceModePersistence(placeModePersistence)
    interactionNode.SetCurrentInteractionMode(interactionNode.Place)
   
    pointListDisplayNode = self.fourPoints.GetDisplayNode()
    pointListDisplayNode.SetSelectedColor(1,1,0)


  def max2D(self):
    layoutManager = slicer.app.layoutManager()
    layoutManager.setLayout(slicer.vtkMRMLLayoutNode.SlicerLayoutOneUpRedSliceView)
    redSliceCompositeNode = slicer.mrmlScene.GetNodeByID("vtkMRMLSliceCompositeNodeRed")
    if redSliceCompositeNode:
        redSliceCompositeNode.SetBackgroundVolumeID(redSliceCompositeNode.GetBackgroundVolumeID())
  
  def fourUp(self):

    layoutManager = slicer.app.layoutManager()
    layoutManager.setLayout(slicer.vtkMRMLLayoutNode.SlicerLayoutFourUpView)


  def comStandLocation(self):#print 4s tandard points position
    standardList=[]
    width=int(self.ui.widthEdit.text)
    height=int(self.ui.heightEdit.text)
    
    To1=[-width/2,height/2,height/2]
    To2=[width/2,height/2,height/2]
    To3=[width/2,-height/2,height/2]
    To4=[-width/2,-height/2,height/2]

    standardList.append(To1)
    standardList.append(To2)
    standardList.append(To3)
    standardList.append(To4)

    return standardList
  
  def changeOrder(self,vtkpoints):#creat order for 4 points

    from_new = []
    for i in range(4):
        point = [0, 0, 0] 
        vtkpoints.GetPoint(i, point) 
        from_new.append(point) 

    # order by x
    points_sorted_by_x = sorted(from_new, key=lambda point: point[0], reverse=True)

    x_max_points = points_sorted_by_x[:2]

    x_max_points_sorted_by_y = sorted(x_max_points, key=lambda point: point[1], reverse=True)
    B = x_max_points_sorted_by_y[0]
    C = x_max_points_sorted_by_y[1]

    remaining_points = points_sorted_by_x[2:]
    remaining_points_sorted_by_y = sorted(remaining_points, key=lambda point: point[1], reverse=True)
    A = remaining_points_sorted_by_y[0]
    D= remaining_points_sorted_by_y[1]

    from_new.clear()
    from_new.append(A)
    from_new.append(B)
    from_new.append(C)
    from_new.append(D)

    from_points_vtk = vtk.vtkPoints() 
    for point in from_new:
      from_points_vtk.InsertNextPoint(point)

    return from_points_vtk,from_new
  
  def autoFourpoints(self):
      if self.fourPoints is None :
        slicer.util.messageBox("Please Select 4 Points")
        return
      n = self.fourPoints.GetNumberOfControlPoints()
      if n != 4:
        slicer.util.messageBox("Please Select 4 Points")
        return
      
      leksell = self.ui.ctDataSelector.currentNode()
      rass=self.track.startTrack(leksell,self.fourPoints)
      for i in range(4):
         self.fourPoints.SetNthControlPointPosition(i,rass[i])

      self.on_register_point()
         
  def on_register_point(self):#to register
    self.fourUp()

    stan=self.comStandLocation() 

    self.showStandPoints(stan) 

    if self.fourPoints is None :
      slicer.util.messageBox("Please Select 4 Points")
      return
    n = self.fourPoints.GetNumberOfControlPoints()
    if n != 4:
      slicer.util.messageBox("Please Select 4 Points")
      return

    fromPointsOrdered = vtk.vtkPoints()
    toPointsOrdered = vtk.vtkPoints()

    for i in range(4):
      ras = vtk.vtkVector3d(0,0,0)
      self.fourPoints.GetNthControlPointPositionWorld(i,ras)
      fromPointsOrdered.InsertPoint(i, ras)
      toPointsOrdered.InsertPoint(i, stan[i])

    P = np.array([fromPointsOrdered.GetPoint(i) for i in range(4)]) 
    Q = np.array([toPointsOrdered.GetPoint(i) for i in range(4)])  
    #calculatedTransform =self.sc.kabsch(P,Q)

    landmarkTransform = vtk.vtkLandmarkTransform()
    landmarkTransform.SetSourceLandmarks(fromPointsOrdered)
    landmarkTransform.SetTargetLandmarks(toPointsOrdered)
    landmarkTransform.SetModeToSimilarity()
    landmarkTransform.Update()
    calculatedTransform = vtk.vtkMatrix4x4()
    landmarkTransform.GetMatrix(calculatedTransform)

    self.outputTransformNode = slicer.mrmlScene.GetFirstNodeByName("pTrans")
    if(self.outputTransformNode is None):
      self.outputTransformNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLTransformNode", "pTrans")
    self.outputTransformNode.SetMatrixTransformToParent(calculatedTransform)
    self.fourPoints.SetAndObserveTransformNodeID(self.outputTransformNode.GetID())

    leksell = self.ui.ctDataSelector.currentNode()
    if leksell:
      leksell.SetAndObserveTransformNodeID(self.outputTransformNode.GetID())

    layoutManager = slicer.app.layoutManager()
    threeDWidget = layoutManager.threeDWidget(0) 
    threeDView = threeDWidget.threeDView()
    threeDView.resetFocalPoint() 
    slicer.util.resetSliceViews()
    
   
    total_error = 0.0
    num_points = fromPointsOrdered.GetNumberOfPoints()

    for i in range(num_points):

        source_point = [0.0, 0.0, 0.0]
        fromPointsOrdered.GetPoint(i, source_point)
      
        transformed_point = [0.0, 0.0, 0.0]
        landmarkTransform.TransformPoint(source_point, transformed_point)
        
        target_point = [0.0, 0.0, 0.0]
        toPointsOrdered.GetPoint(i, target_point)
        
        error = math.sqrt(
            (transformed_point[0] - target_point[0])**2 + 
            (transformed_point[1] - target_point[1])**2 + 
            (transformed_point[2] - target_point[2])**2 
        )
        
        total_error += error

    rms_error =round(total_error / num_points,2)
    if rms_error>1.5:
       slicer.util.warningDisplay("The error is too large. Please re-register.", windowTitle="Warning")

    self.ui.errortext.setText(str(rms_error))
  
  def hidePoints(self):
    node1= self.fourPoints
    node2= self.sPoints
    if node1 and node2:
      node1.GetDisplayNode().SetVisibility(0)
      node2.GetDisplayNode().SetVisibility(0)

####################################################################################### for target and entry
  def on_add_target_point(self):

    self.hidePoints()

    self.target = slicer.mrmlScene.GetFirstNodeByName("targetPoint")
    if self.target is None:
      self.target = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLMarkupsFiducialNode", "targetPoint")
    self.target.RemoveAllControlPoints()

    self.target.GetDisplayNode().SetGlyphType(6)

    self.target.AddObserver(slicer.vtkMRMLMarkupsNode.PointModifiedEvent, functools.partial(self.on_point_modified, actor="t"))  #点变动的时候

    #self.target.AddObserver(slicer.vtkMRMLMarkupsNode.PointStartInteractionEvent, self.observerStartMove) 
    self.target.AddObserver(slicer.vtkMRMLMarkupsNode.PointEndInteractionEvent, self.observerEndMove)

    interactionNode = slicer.app.applicationLogic().GetInteractionNode()
    selectionNode = slicer.app.applicationLogic().GetSelectionNode()
    selectionNode.SetActivePlaceNodeID(self.target.GetID())
    interactionNode.SetPlaceModePersistence(0)
    interactionNode.SetCurrentInteractionMode(interactionNode.Place)


  def on_add_entry_point(self):
    self.entry = slicer.mrmlScene.GetFirstNodeByName("entryPoint")
    if(self.entry is None):
      self.entry = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLMarkupsFiducialNode", "entryPoint")
    self.entry.RemoveAllControlPoints()

    self.entry.GetDisplayNode().SetGlyphType(6)

    self.entry.GetDisplayNode().SetGlyphSize(10)

    self.entry.AddObserver(slicer.vtkMRMLMarkupsNode.PointModifiedEvent, functools.partial(self.on_point_modified, actor="e"))

    #self.entry.AddObserver(slicer.vtkMRMLMarkupsNode.PointStartInteractionEvent, self.observerStartMove)
    self.entry.AddObserver(slicer.vtkMRMLMarkupsNode.PointEndInteractionEvent, self.observerEndMove)

    interactionNode = slicer.app.applicationLogic().GetInteractionNode()
    selectionNode = slicer.app.applicationLogic().GetSelectionNode()
    selectionNode.SetActivePlaceNodeID(self.entry.GetID())
    interactionNode.SetPlaceModePersistence(0)
    interactionNode.SetCurrentInteractionMode(interactionNode.Place)

  def newPlan(self):  #copy a tube
    self.sc.addPlan(self.tubeModel)


####################################################################################### Observer 
  def on_point_modified(self, caller, event, actor=None,):

    if actor=="f":
      self.observeFourPoints()

    self.observeTarEnt()

    self.observeCreatTube()

    if self.realTimeVis:
      self.loadFrame()

    if self.target is not None and actor=="t":
      ras = [0.0, 0.0, 0.0]
      self.target.GetNthControlPointPosition(0, ras)
      self.sc.jumpToSlice(ras[0],ras[1],ras[2])

    if self.entry is not None and actor=="e":
      ras = [0.0, 0.0, 0.0]
      self.entry.GetNthControlPointPosition(0, ras)
      self.sc.jumpToSlice(ras[0],ras[1],ras[2])

  def observeTarEnt(self):# get the distance from target to entry  and rename the target  entry

      for node, label in [(self.entry, "  - - -entry"), (self.target, "  - - -target")]:
              if node and node.GetNumberOfControlPoints() > 0:
                  node.SetNthControlPointLabel(0, label)

      if self.entry and self.entry.GetNumberOfControlPoints() > 0 and self.target and self.target.GetNumberOfControlPoints() > 0:
    
          entry_position = [0.0, 0.0, 0.0]
          self.entry.GetNthControlPointPosition(0, entry_position)

          target_position = [0.0, 0.0, 0.0]
          self.target.GetNthControlPointPosition(0, target_position)

          distance = np.linalg.norm(np.array(entry_position) - np.array(target_position))
          self.ui.distanceText.setText(str(round(distance,2)))
          #print(f"Entry Point to Target Point Distance: {distance:.2f} mm")

          target_ras= vtk.vtkVector3d(0,0,0)
          self.target.GetNthControlPointPositionWorld(0,target_ras)

          entry_ras= vtk.vtkVector3d(0,0,0)
          self.entry.GetNthControlPointPositionWorld(0,entry_ras)

          ################  cal result
          lekResult=self.sc.calResult(target_ras,entry_ras)
          self.ui.final_x.setText(lekResult[0].__str__())
          self.ui.final_y.setText(lekResult[1].__str__())
          self.ui.final_z.setText(lekResult[2].__str__())
          self.ui.Arc.setText(lekResult[3].__str__())
          self.ui.Ring.setText(lekResult[4].__str__())
      
      else:
         if self.target and self.target.GetNumberOfControlPoints() > 0:
          target_ras= vtk.vtkVector3d(0,0,0)
          self.target.GetNthControlPointPositionWorld(0,target_ras)
          lekResult=self.sc.calResult(target=target_ras)
          self.ui.final_x.setText(lekResult[0].__str__())
          self.ui.final_y.setText(lekResult[1].__str__())
          self.ui.final_z.setText(lekResult[2].__str__())

    ##observe 4 points
  
  def observeFourPoints(self):# 
      self.fourPoints = slicer.mrmlScene.GetFirstNodeByName("pointset")
      node=self.fourPoints
      if node:
        n = node.GetNumberOfControlPoints()
        interactionNode = slicer.mrmlScene.GetFirstNodeByClass("vtkMRMLInteractionNode")
        if n > 4:
          interactionNode = slicer.app.applicationLogic().GetInteractionNode()
          interactionNode.SetCurrentInteractionMode(interactionNode.ViewTransform)

          nodeVtkPoints=vtk.vtkPoints()
          for i in range(4):
            ras = vtk.vtkVector3d(0,0,0)
            node.GetNthControlPointPositionWorld(i,ras)
            nodeVtkPoints.InsertPoint(i, ras)
          _,nodeListPoints=self.changeOrder(nodeVtkPoints)
          node.RemoveAllControlPoints()
          node.GetDisplayNode().SetGlyphType(2)
          name=["    a","    b","    c","    d"]
          for i in range(4):
            node.AddControlPointWorld(nodeListPoints[i])
            node.SetNthControlPointLabel(i,name[i])
  
  def observeCreatTube(self):
    if self.target and self.entry:
        p1 = [0, 0, 0]
        self.target.GetNthControlPointPositionWorld(0, p1)
        p2 = [0, 0, 0]
        self.entry.GetNthControlPointPositionWorld(0, p2)

        tube=self.sc.updateTube(p1,p2)
                # 更新或创建模型
        if self.tubeModel is None:
            self.tubeModel = slicer.modules.models.logic().AddModel(tube.GetOutputPort())
            self.tubeModel.SetName("tubeModel")
            
        else:
            self.tubeModel.SetPolyDataConnection(tube.GetOutputPort())

        self.tubeModel.GetDisplayNode().SetColor(1,0,0)

        self.tubeModel.GetDisplayNode().SetSliceIntersectionVisibility(1)

        self.tubeModel.GetDisplayNode().SetOpacity(0.5)

  def observerStartMove(self,caller, event):
    if self.tubeModel is not None:
      self.tubeModel.GetDisplayNode().SetVisibility(0)
 
  def observerEndMove(self,caller, event):
    #if self.tubeModel is not None:
     # self.tubeModel.GetDisplayNode().SetVisibility(1)
     self.syncPlan()
  
  def reset(self):
    nodeList=[
            self.sPoints,
            self.fourPoints,
            self.outputTransformNode,
            self.target,
            self.entry,
            self.tubeModel,
            self.frameModel,
            self.arcModel,
            self.pathModel,
            self.pathTranNode,
            self.arcTranNode,
            self.axialModel
   ] 

    for i in nodeList:
      if i!=None:
        slicer.mrmlScene.RemoveNode(i)


    self.ui.Arc.setText("0")
    self.ui.Ring.setText("0")
    

    self.ui.final_x.setText("100")
    self.ui.final_y.setText("100")
    self.ui.final_z.setText("100")

    self.ui.errortext.setText("0")
    self.ui.distanceText.setText("0")

    self.defineiVar()

#######################################################################################  For Simulation
  def loadFrame(self):
    arc=slicer.mrmlScene.GetFirstNodeByName("Arc")
    frame=slicer.mrmlScene.GetFirstNodeByName("Frame")
    path=slicer.mrmlScene.GetFirstNodeByName("Path")
    axial=slicer.mrmlScene.GetFirstNodeByName("Axial")
    pathTran=slicer.mrmlScene.GetFirstNodeByName("pathTran")
    arcTran=slicer.mrmlScene.GetFirstNodeByName("arcTran")

    if arc :
      pass

    else:

        self.frameModel=slicer.util.loadModel(self.resourcePath('frame/Frame.stl'))
        self.frameModel.GetDisplayNode().SetColor(1,238/255,0)

        self.arcModel=slicer.util.loadModel(self.resourcePath('frame/Arc.stl'))
        self.arcModel.GetDisplayNode().SetColor(1,238/255,0)

        self.pathModel=slicer.util.loadModel(self.resourcePath('frame/Path.stl'))
        self.pathModel.GetDisplayNode().SetColor(0,1,42/255)

        self.axialModel=slicer.util.loadModel(self.resourcePath('frame/Axial.stl'))
        self.axialModel.GetDisplayNode().SetColor(1,0,0)

        """
        self.r0Model = slicer.util.loadModel(self.resourcePath('frame/R0.stl'))
        self.r0Model.GetDisplayNode().SetColor(1, 0.5, 0)

        self.r1Model = slicer.util.loadModel(self.resourcePath('frame/R1.stl'))
        self.r1Model.GetDisplayNode().SetColor(1, 238 / 255, 0)

        self.r2Model = slicer.util.loadModel(self.resourcePath('frame/R2.stl'))
        self.r2Model.GetDisplayNode().SetColor(1, 238 / 255, 0)

        self.r3Model = slicer.util.loadModel(self.resourcePath('frame/R3.stl'))
        self.r3Model.GetDisplayNode().SetColor(1, 238 / 255, 0)

        self.r4Model = slicer.util.loadModel(self.resourcePath('frame/R4.stl'))
        self.r4Model.GetDisplayNode().SetColor(1, 238 / 255, 0)
        """
        
        self.pathTranNode=slicer.mrmlScene.AddNewNodeByClass("vtkMRMLTransformNode", "pathTran")
        self.arcTranNode=slicer.mrmlScene.AddNewNodeByClass("vtkMRMLTransformNode", "arcTran")

        self.pathModel.SetAndObserveTransformNodeID(self.pathTranNode.GetID())

        self.arcModel.SetAndObserveTransformNodeID(self.arcTranNode.GetID())

        self.pathTranNode.SetAndObserveTransformNodeID(self.arcTranNode.GetID())

    self.syncPlan()


  def loadTestCt(self):
     ctPath=self.resourcePath('ctData/test_CT.nrrd')
     slicer.util.loadVolume(ctPath)
     self.ui.ctDataSelector.setCurrentNode(slicer.util.getNode("test_CT"))

  def syncPlan(self):#同步框架位置，将结果输入到下方框架控制区

      self.ui.axTransSlicer.setValue(float(self.ui.final_x.text))
      self.ui.ayTransSlicer.setValue(float(self.ui.final_y.text))
      self.ui.azTransSlicer.setValue(float(self.ui.final_z.text))
      self.ui.axRotateSlicer.setValue(float(self.ui.Ring.text))

      self.ui.pRotateSlicer.setValue(float(self.ui.Arc.text))

  def pRotate(self):
      value=180-self.ui.pRotateSlicer.value
      transformNode=self.pathTranNode
      transformMatrix = transformNode.GetMatrixTransformToParent()
      transform = vtk.vtkTransform()
      transform.RotateY(value)
      transform.Translate(0,0,0)
      transformMatrix = transform.GetMatrix()
      transformNode.SetMatrixTransformToParent(transformMatrix)

  def axyzRotate(self):
      x=self.ui.axTransSlicer.value
      y=self.ui.ayTransSlicer.value
      z=self.ui.azTransSlicer.value
      ro=self.ui.axRotateSlicer.value
      transformNode=self.arcTranNode
      transform = vtk.vtkTransform()
      transform.Translate(100-x,y-100,100-z)
      transform.RotateX(ro-90)
      transformMatrix = transform.GetMatrix()
      transformNode.SetMatrixTransformToParent(transformMatrix)
      
  def visualFrame(self):
    if self.frameModel is not None:
      self.frameModel.GetDisplayNode().SetVisibility(1-self.frameModel.GetDisplayVisibility())

  def realTimeTrac(self):
    self.realTimeVis = not self.realTimeVis

  def lockPlan(self):
    if self.target!=None and self.entry!=None:
      self.target.SetLocked(1-self.target.GetLocked())
      self.entry.SetLocked(1-self.entry.GetLocked())



  def volumeRender(self):
    currentNode=self.ui.ctDataSelector.currentNode()

    volRenLogic = slicer.modules.volumerendering.logic()
    displayNode = volRenLogic.CreateDefaultVolumeRenderingNodes(currentNode)
    displayNode.SetVisibility(True)
    displayNode.GetVolumePropertyNode().Copy(volRenLogic.GetPresetByName("CT-Chest-Contrast-Enhanced"))

    layoutManager = slicer.app.layoutManager()
    threeDWidget = layoutManager.threeDWidget(0) 
    threeDView = threeDWidget.threeDView()
    threeDView.resetFocalPoint() 
    slicer.util.resetSliceViews()


class track:

    def __init__(self, parent=None):
       pass


    def startTrack(self,volumeNode,trackPointNode):

        trackPoint= trackPointNode  # 这里的 'Fiducials' 是 Fiducial 节点的名称

        # 获取该节点的数量
        num_fiducials = trackPoint.GetNumberOfControlPoints()

        rass=[]

        for i in range(num_fiducials):
           ras = trackPoint.GetNthControlPointPosition(i)

           ijk=self.RAS2IJK(volumeNode,ras)

           ras=self.trackLogic(volumeNode,ijk[0],ijk[1])
           rass.append(ras)

        return rass


    def trackLogic(self,volumeNode=None,i=None,j=None):  #输入影像节点，和一个点ij点，返回追踪结束后的RAS坐标

        search_radius=8   #搜索半径

        k,off=self.getIndex()

        ori_array  = slicer.util.array(volumeNode.GetID())

        ks=ori_array.shape[0]-k  #往上剩余的层数,包含本层
 
        center_x = i 
        center_y = j 

        for i in range(ks):
            index = k + i
            # 获取当前层数据
            img = ori_array[index, :, :]

            # 确定搜索区域（限制在图像范围内）
            y_min = int(max(0, center_y - search_radius))
            y_max = int(min(img.shape[0], center_y + search_radius))
            x_min = int(max(0, center_x - search_radius))
            x_max = int(min(img.shape[1], center_x + search_radius))

            # 在搜索范围内寻找最大灰度值
            roi = img[y_min:y_max, x_min:x_max]
            maxVal = np.max(roi)
            maxLoc = np.unravel_index(np.argmax(roi), roi.shape) 

            if maxVal <400: #停止追踪的CT值
              break

            # 更新新中心点 (注意：maxLoc 是局部坐标，需要转换回全局坐标)
            center_x = x_min + maxLoc[1]
            center_y = y_min + maxLoc[0]

            cor=[center_x, center_y,index]
            ras=self.IJK2RAS(volumeNode,cor)

   
            
        return ras

    
    def IJK2RAS(self,VolumeNode,ijk):#返回RAS坐标
        
        ijk2ras = vtk.vtkMatrix4x4()
        VolumeNode.GetIJKToRASMatrix(ijk2ras)

        ijk_p=np.array([ijk[0], ijk[1], ijk[2]] + [1.0])
        
        ras_point =ijk2ras.MultiplyFloatPoint(ijk_p)
        return ras_point[:3]
    
    def RAS2IJK(self,VolumeNode,ras):#返回RAS坐标
    # 获取IJK到RAS的转换矩阵
        rasToijk = vtk.vtkMatrix4x4()
        VolumeNode.GetRASToIJKMatrix(rasToijk )

        ras_p = np.array([ras[0], ras[1], ras[2], 1.0])
        # 使用矩阵乘法将 RAS 坐标转换为 IJK 坐标
        ijk_point =np.round(rasToijk.MultiplyFloatPoint(ras_p)) 
        
        # 返回转换后的 IJK 坐标
        return ijk_point[:3]

    def getIndex(self):#获取当前视图的索引值和实际偏移量

        red_logic = slicer.app.layoutManager().sliceWidget("Red").sliceLogic()
        offset=red_logic.GetSliceOffset()
        k=red_logic.GetSliceIndexFromOffset(offset)-1
        return k,offset


    def jumpTok(self,offset=0):
        # 获取 Red 视图的逻辑对象
        red_logic = slicer.app.layoutManager().sliceWidget("Red").sliceLogic()
        red_logic.SetSliceOffset(offset)

    def otherInfo(volumeNode):
        ScalarRange= volumeNode.GetImageData().GetScalarRange()
        Bounds=volumeNode.GetImageData().GetBounds()
        Center=volumeNode.GetImageData().GetCenter()
        Dimensions=volumeNode.GetImageData().GetDimensions()
        DirectionMatrix=volumeNode.GetImageData().GetDirectionMatrix()